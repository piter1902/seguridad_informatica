# Cómo compilar y ejecutar el programa

- Compilación: `javac Compra.java`
- Ejecución:   `java Compra`
- Opcional: Si se desea poner de nuevo todos los valores del programa (carrito, compra) por defecto, ejecutar
  * `cp *.txt backEndOrig/`  